<?php
$assets_location = base_url()."aset/dashboard/";
?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            <strong>Welcome Back</strong><small> Admin</small>
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-dashboard"></i> Koperasi Mahasiswa ITS
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
