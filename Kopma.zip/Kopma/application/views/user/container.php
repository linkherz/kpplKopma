<?php
$assets_location = base_url()."aset/Regna/";
?>


  <!--==========================
    Hero Section
  ============================-->
  <section id="hero">
    <div class="hero-container">
      <h1>Selamat Datang di Koperasi Mahasiswa </h1>
      <h2>Institut Teknologi Sepuluh Nopember</h2>
      <a href="#about" class="btn-get-started">Kopma</a>
    </div>
  </section><!-- #hero -->

  <main id="main">
